--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 14.5
-- Dumped by pg_dump version 14.5

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE progetto;
--
-- Name: progetto; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE progetto WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE = 'Italian_Italy.1252';


ALTER DATABASE progetto OWNER TO postgres;

\connect progetto

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: public; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA public;


ALTER SCHEMA public OWNER TO postgres;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON SCHEMA public IS 'standard public schema';


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: acquirente; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.acquirente (
    idacquirente bigint NOT NULL,
    nome character varying NOT NULL,
    cognome character varying NOT NULL,
    idvenditore bigint NOT NULL
);


ALTER TABLE public.acquirente OWNER TO postgres;

--
-- Name: amministratore; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.amministratore (
    idamministratore bigint NOT NULL,
    nome character varying NOT NULL,
    cognome character varying NOT NULL,
    idacquirente bigint NOT NULL,
    idvenditore bigint NOT NULL
);


ALTER TABLE public.amministratore OWNER TO postgres;

--
-- Name: venditore; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.venditore (
    idvenditore bigint NOT NULL,
    nome character varying NOT NULL,
    cognome character varying NOT NULL,
    idacquirente bigint NOT NULL
);


ALTER TABLE public.venditore OWNER TO postgres;

--
-- Data for Name: acquirente; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.acquirente (idacquirente, nome, cognome, idvenditore) FROM stdin;
\.
COPY public.acquirente (idacquirente, nome, cognome, idvenditore) FROM '$$PATH$$/3320.dat';

--
-- Data for Name: amministratore; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.amministratore (idamministratore, nome, cognome, idacquirente, idvenditore) FROM stdin;
\.
COPY public.amministratore (idamministratore, nome, cognome, idacquirente, idvenditore) FROM '$$PATH$$/3322.dat';

--
-- Data for Name: venditore; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.venditore (idvenditore, nome, cognome, idacquirente) FROM stdin;
\.
COPY public.venditore (idvenditore, nome, cognome, idacquirente) FROM '$$PATH$$/3321.dat';

--
-- Name: acquirente acquirente_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.acquirente
    ADD CONSTRAINT acquirente_pk PRIMARY KEY (idacquirente);


--
-- Name: amministratore amministratore_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.amministratore
    ADD CONSTRAINT amministratore_pk PRIMARY KEY (idamministratore);


--
-- Name: venditore venditore_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.venditore
    ADD CONSTRAINT venditore_pk PRIMARY KEY (idvenditore);


--
-- Name: acquirente acquirente_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.acquirente
    ADD CONSTRAINT acquirente_fk FOREIGN KEY (idvenditore) REFERENCES public.venditore(idvenditore);


--
-- Name: amministratore amministratore_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.amministratore
    ADD CONSTRAINT amministratore_fk FOREIGN KEY (idacquirente) REFERENCES public.acquirente(idacquirente);


--
-- Name: amministratore amministratore_fk_1; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.amministratore
    ADD CONSTRAINT amministratore_fk_1 FOREIGN KEY (idvenditore) REFERENCES public.venditore(idvenditore);


--
-- Name: venditore venditore_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.venditore
    ADD CONSTRAINT venditore_fk FOREIGN KEY (idacquirente) REFERENCES public.acquirente(idacquirente);


--
-- PostgreSQL database dump complete
--

